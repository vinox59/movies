import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../../app.service';

@Component({
  selector: 'app-theatre-list',
  templateUrl: './theatre-list.component.html',
  styleUrls: ['./theatre-list.component.scss']
})
export class TheatreListComponent implements OnInit {

  theatreList: any[] = [];
  moviesList: any[] = [];

  constructor(private _service: AppService, private router: Router) { }

  ngOnInit(): void {
    this._service.loadAllDetails().subscribe(res => {
      if(res) {
        this._service.allDetails = res;
        //@ts-ignore
        this.theatreList = res.theatre;
        //@ts-ignore
        this.moviesList = res.movies;
      }
    });
  }

  passMovieDetail(theatre: any) {
    this._service.selectedTheatre = theatre;
    this.router.navigate(['/theatres/theatre/'+ theatre.theatre_name]);
  }

  

}
