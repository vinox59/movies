import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';

import { TheatreRoutingModule } from './theatre-routing.module';
import { TheatreListComponent } from './theatre-list/theatre-list.component';
import { MoviesListComponent } from './movies-list/movies-list.component';


@NgModule({
  declarations: [
    TheatreListComponent,
    MoviesListComponent
  ],
  imports: [
    CommonModule,
    TheatreRoutingModule,
    NgbTooltipModule
  ]
})
export class TheatreModule { }
