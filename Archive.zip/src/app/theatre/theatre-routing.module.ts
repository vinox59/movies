import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MoviesListComponent } from './movies-list/movies-list.component';
import { TheatreListComponent } from './theatre-list/theatre-list.component';


const routes: Routes = [{
  path:'list',
  component: TheatreListComponent
}, {
  path:'theatre/:id',
  component: MoviesListComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TheatreRoutingModule { }
