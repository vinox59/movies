import { Component, OnInit} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AppService } from '../../app.service';
 
@Component({
  selector: 'app-movies-list',
  templateUrl: './movies-list.component.html',
  styleUrls: ['./movies-list.component.scss']
})
export class MoviesListComponent implements OnInit {

  title!: string;
  moviesDetail: any;
  allMoviesList: any;
  objMovies: any = {};
  movieList: any[] = ['show1_movie','show2_movie','show3_movie','show4_movie'];
  showList: any[] = ['show1_time','show2_time','show3_time','show4_time'];

  movies: any = {};

  iternateMovies: any[] = [];

  constructor(private activateRoute: ActivatedRoute, private service: AppService) { }

  ngOnInit(): void {
    this.activateRoute.params.subscribe(para => {
      this.title = para['id'];
    });
    this.moviesDetail = this.service.selectedTheatre;
    this.allMoviesList = this.service.allDetails.movies;
    this.allMoviesList.forEach((e: any) => {
      this.objMovies[e.movie_name] = e
    })
    console.log(this.objMovies)
    this.movieList.forEach((e, i) => {
      if(this.movies.hasOwnProperty(this.moviesDetail[e])) {
        this.movies[this.moviesDetail[e]].push(this.moviesDetail[this.showList[i]])
      } else {
        this.movies[this.moviesDetail[e]] = [this.moviesDetail[this.showList[i]]];
      }
    });
    console.log(this.movies);
    for(let i in this.movies) {
     const obj = {
       details: this.objMovies[i],
       showTime: this.movies[i]
     }
     this.iternateMovies.push(obj);
    }
    console.log(this.iternateMovies);
  }

}
