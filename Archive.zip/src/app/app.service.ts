import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private _http: HttpClient) { }

  allDetails: any;
  selectedTheatre: any;

  loadAllDetails() {
    const url = 'https://zincubate.in/api/MovieTicketChecker?action=getAllDetails';
    const payload = {user_mail_id: "info.anandsubash@gmail.com"}
    return this._http.post(url, payload)
  }
}
