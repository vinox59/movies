import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [{
  path:'',
  redirectTo: 'theatres/list',
  pathMatch: 'full'
}, {
  path: 'theatres',
  loadChildren: () => import('./theatre/theatre.module').then(m => m.TheatreModule)
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
